-- Set up rail communication and enable rail
ExtDevSetUDPComParam("192.168.57.88", 2021, 2, 50, 10, 50, 1, 2, 5)
ExtDevLoadUDPDriver()
ExtAxisServoOn(1,1)

SetAuxDO(0,1,0,0) -- Set switch input to high
--[[
EXT_AXIS_PTP(0,ExtAxisZero,100)


SetDO(0, 1, 0, 0)
while(1) do
    if GetDI(3,0) == 1 then
        SetDO(0,0,0,0)
        EXT_AXIS_PTP(0,ExtAxisUp,100)
        WaitMs(100)
        EXT_AXIS_PTP(0,ExtAxisZero,100)
        SetDO(0,1,0,0)
    end
    WaitMs(1000)
end
--]]
