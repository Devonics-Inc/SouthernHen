-- Set up rail communication and enable rail

ExtDevSetUDPComParam("192.168.57.88", 2021, 2, 50, 10, 50, 1, 2, 5)
ExtAxisServoOn(1,1)
ExtDevLoadUDPDriver()

SetAuxDO(5,1,0,0) -- Disengage rail break
EXT_AXIS_PTP(0,RtRobotGrab,100)
PTP(RtRobotGrab,50,50,0)
Lin(RtRobotGrab,100,-1,0,1,0,0,-5,0,0,0)
SetDO(3,1,0,0)
WaitMs(500)
PTP(RtMidPt,50,50,0)
PTP(RtPalletBIC, 50, -1, 0)
SetDO(3,0,0,0)


