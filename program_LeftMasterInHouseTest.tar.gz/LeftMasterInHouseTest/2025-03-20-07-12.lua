SetDO(0,1,0,1)
SetDO(0,0,0,1)