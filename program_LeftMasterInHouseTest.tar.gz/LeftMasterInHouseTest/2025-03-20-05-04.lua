SetDO(0,0,0,0)
GetDI(0,0)