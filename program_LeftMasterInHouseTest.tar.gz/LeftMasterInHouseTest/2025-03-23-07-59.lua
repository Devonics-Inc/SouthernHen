-- Set up rail communication and enable rail

ExtDevSetUDPComParam("192.168.57.88", 2021, 2, 50, 10, 50, 1, 2, 5)
ExtAxisServoOn(1,1)
ExtDevLoadUDPDriver()

SetAuxDO(5,1,0,0) -- Disengage rail break
PTP(RtMidPt,50,50,0) -- SetUP pt

PTP(RtRobotGrabHigh,100,100,0)
SetDO(3,1,0,0)
Lin(RtRobotGrabHigh,100,-1,0,1,0,0,-165,0,0,0)
WaitMs(70)
PTP(RtRobotGrabHigh,100,-1,0)
ARC(RtMidPt,0,0,0,0,0,0,0,RtPalletBIC,0,0,0,0,0,0,0,100,100)
SetDO(3,0,0,0)
ARC(RtMidPt,0,0,0,0,0,0,0,RtRobotGrabHigh,0,0,0,0,0,0,0,100,100)
Lin(RtRobotGrabHigh,100,-1,0,1,0,0,-165,0,0,0)
