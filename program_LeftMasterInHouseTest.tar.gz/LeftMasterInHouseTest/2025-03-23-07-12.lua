-- Set up rail communication and enable rail
ExtDevSetUDPComParam("192.168.57.88", 2021, 2, 50, 10, 50, 1, 2, 5)
ExtAxisServoOn(1,1)
ExtDevLoadUDPDriver()

SetAuxDO(5,1,0,0) -- Disengage rail break
EXT_AXIS_PTP(0,RtRobotGrab,100)
PTP(RtRobotGrab,50,-1,0)
Lin(CenterPtRailZero,100,-1,0,1,0,0,-5,0,0,0)
SetDO(3,1,0,0)
EXT_AXIS_PTP(0,RtMidPt,100)
--[[
EXT_AXIS_PTP(0,RtMidPt,100)
PTP(RtMidPt,50,-1,0)
--]]

--[[
SetDO(0, 1, 0, 0)
while(1) do
    if GetDI(3,0) == 1 then
        SetDO(0,0,0,0)
        EXT_AXIS_PTP(0,ExtAxisUp,100)
        WaitMs(100)
        EXT_AXIS_PTP(0,ExtAxisZero,100)
        SetDO(0,1,0,0)
    end
    WaitMs(1000)
end
--]]
