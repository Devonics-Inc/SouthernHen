SetDO(0,1,0,0)
GetDI(0,0)