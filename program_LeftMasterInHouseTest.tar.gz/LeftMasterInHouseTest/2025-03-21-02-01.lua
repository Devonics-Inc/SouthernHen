SetAuxDO(5,1,0,0)
ExtDevSetUDPComParam("192.168.57.88", 2021, 2, 50, 10, 50, 1, 2, 5)
ExtDevLoadUDPDriver()
ExtAxisServoOn(1,1)
while(1):
    if GetDI(3,0) then
        WaitMS(10)
    end
end

--[[ SetDO(0,1,0,1)
SetDO(0,0,0,1)
WaitMs(1000)
EXT_AXIS_PTP(0,zero,50) --]]