ExtDevSetUDPComParam("192.168.57.88", 2021, 2, 50, 10, 50, 1, 2, 5)
ExtDevLoadUDPDriver()
ExtAxisServoOn(1,1)
SetAuxDO(5,1,0,0)

while(1) do
    if GetDI(3,0) == 1 then
        EXT_AXIS_PTP(0,ExtAxisUp,100)
        SetDO(0,0)
    else
        EXT_AXIS_PTP(0,ExtAxisZero,100)
        SetDO(0,1)
    end
    WaitMs(100)
end
