SetDO(0,1,0,1)
SetDO(0,0,0,1)
ExtAxisServoOn(1,1)
EXT_AXIS_PTP(0, 0, 100)