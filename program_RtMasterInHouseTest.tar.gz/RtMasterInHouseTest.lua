-- Set up rail communication and enable rail
ExtDevSetUDPComParam("192.168.57.88", 2021, 2, 50, 10, 50, 1, 2, 5)
ExtDevLoadUDPDriver()
ExtAxisServoOn(1,1)
SetAuxDO(5,1,0,0) -- Disengage rail break
SetDO(0, 1, 0, 0) -- Give light switch high signal
-- Temp Vars for small boxes in office
l = 385 --Length of box
w = 325 -- Width of box
h = 320 -- Height of box
-- Loop vars
col = 1 --Collumn counter for loop (INDEX AT 1)
row = 1 --Row counter for loop (INDEX AT 1)
layer = 1 -- Which layer you're building (FIRST LAYER IS 1)
PTP(RtBaseGrab,100,500,1,0,0,(2 * h),0,0,0)
while(1) do
    -- Wait for go signal (either sensor or DO from Master)
    if(GetDI(5, 0) == 1) then
        -- Move to hover pose
        PTP(RtBaseGrab,100,-1,1,0,0,(2 * h),0,0,0)
        SetDO(3,1,0,0) -- Turn on vacuum
        Lin(RtBaseGrab,100,-1,0,1,0,0,h-13,0,0,0)-- Go to 5 mm below height of box
        WaitMs(300) -- Wait to ensure suction
        Lin(RtBaseGrab,50,-1,0,1,0,0,h + 165,0,0,0) -- Go straight up after grab
        -- Either put the go signal for the slave here...
        -- SetDO(SlaveGo, 1, 0, 0)
        PTP(RtMidPt,100,500,1, ((col-3) * l)/2,0,layer * h,0,0,0)-- Go to mid pt (might need an ofset in the field)
        -- ...or here. Depends on how much faith you have in max speed
        -- Place box in prep spot (10mm offset in all directions)
        PTP(RtBaseDropBIC, 100,500,1, ((col-1) * l) + 20, -1 * ((row-1) * w) - 20, (h * layer) + 50, 0, 0, 0)
        -- Do linear drop to pallet position to ensure minimal colisions or shifting
        Lin(RtBaseDropBIC,100,500,0,1,((col-1) * l), -1 * ((row-1) * w),(h * layer)-10,0,0,0)
        SetDO(3,0,0,0) -- Release gripper
        WaitMs(300) -- Wait to ensure vacuum is released
        -- TO DO HERE: Read GO sensor from either sensor or Master
        -- If GO sensor is high: go straight to pickup W vertical offset
        -- PTP(RtBaseGrab,100,-1,1,0,0,(2 * h),0,0,0) -- GO to grab prep
        -- else: Go to prep pos and check GO sensor at arrival
        PTP(RtPrepPt,100,-1,0) -- Go to prep position to wait for GO signal
        -- Adjust loop values
        if(col % 3 == 0) then
            col = 1
            if(row % 3 == 0) then
                row = 1
                layer = layer + 1
            else
                row = row + 1
            end
        else
            col = col + 1
        end
    end
end