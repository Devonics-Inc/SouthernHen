-- Set up rail communication and enable rail

ExtDevSetUDPComParam("192.168.57.88", 2021, 2, 50, 10, 50, 1, 2, 5)
ExtAxisServoOn(1,1)
ExtDevLoadUDPDriver()
SetAuxDO(5,1,0,0) -- Disengage rail break
SetDO(0, 1) -- Give light switch high signal
-- Temp Vars for small boxes in office
l = 340 --Length of box
w = 330 -- Width of box
h = 330 -- Height of box
-- Loop vars
col = 1 --Collumn counter for loop (INDEX AT 1)
row = 1 --Row counter for loop (INDEX AT 1)
layer = 1 -- Which layer you're building (FIRST LAYER IS 1)
PTP(RtRobotGrabHighV2,100,-1,0)

while(1) do
    if(GetDI(5, 0) == 1) then
        SetDO(3,1,0,0)
        Lin(BaseGrab,100,500,0,1,0,0,h-5,0,0,0) -- Go to 5 mm below height of box
        WaitMs(300)
        PTP(RtRobotGrabHighV2,50,500,0)
        ARC(RtMidPtV2,0,0,0,0,0,0,0,RtBaseDropBIC,1, ((col-1) * l),((row-1) * w), (h * layer),0,0,0,100,300)
        SetDO(3,0,0,0)
        ARC(RtMidPtV2,0,0,0,0,0,0,0,RtRobotGrabHighV2,0,0,0,0,0,0,0,100,0300)
        
        if(col % 3 == 0) then
            col = 0
            if(row % 3 == 0) then
                row = 0
                layer = layer + 1
            else
                row = row + 1
            end
        else
            col = col + 1
        end
    end

end