while(1) do
    SetAuxDO(0,0,0,0)
    WaitMs(500)
    SetAuxDO(1,0,0,0)
    WaitMs(500)
    SetAuxDO(2,0,0,0)
    WaitMs(500)
    SetAuxDO(0,1,0,0)
    WaitMs(500)
    SetAuxDO(1,1,0,0)
    WaitMs(500)
    SetAuxDO(2,1,0,0)
    WaitMs(500)
end