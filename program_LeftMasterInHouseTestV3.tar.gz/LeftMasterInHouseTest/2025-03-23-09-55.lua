-- Set up rail communication and enable rail

ExtDevSetUDPComParam("192.168.57.88", 2021, 2, 50, 10, 50, 1, 2, 5)
ExtAxisServoOn(1,1)
ExtDevLoadUDPDriver()
SetAuxDO(5,1,0,0) -- Disengage rail break

l = 300 --Length of box
w = 300 -- Width of box
h = 100 -- Height of box
col = 0 --Collumn counter for loop
row = 0 --Row counter for loop
layer = 1 -- Which layer you're building (FIRST LAYER IS 1)

while(1) do
    PTP(RtRobotGrabHighV2,100,-1,0)
    if(GetDI(5, 0) == 1) then
        SetDO(3,1,0,0)
        Lin(BaseGrab,100,500,0,1,0,0,h-5,0,0,0) -- Go to 5 mm below height of box
        WaitMs(300)
        PTP(RtRobotGrabHighV2,50,500,0)
        ARC(RtMidPtV2,0,0,0,0,0,0,0,RtBaseDropBIC,1, col * l,row * w, h * layer,0,0,0,100,300)
        SetDO(3,0,0,0)
        ARC(RtMidPtV2,0,0,0,0,0,0,0,RtRobotGrabHighV2,0,0,0,0,0,0,0,100,0300)
    end
end