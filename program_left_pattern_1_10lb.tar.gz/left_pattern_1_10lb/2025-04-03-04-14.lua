layer = GetSysVarValue(s_var_1)
l = GetSysVarValue(s_var_2)
w = GetSysVarValue(s_var_3)
h = GetSysVarValue(s_var_4)

col = GetSysVarValue(s_var_5)
row = GetSysVarValue(s_var_6)
rail_pos = GetSysVarValue(s_var_7)
max_layer = 16
x_offset = 0
y_offset = 0
z_offset = 0
SetAuxDO(0,0,0,0)
SetAuxDO(1,0,0,0)
SetAuxDO(2,1,0,0) -- Use Red
-- Move to hover pose
PTP(Grab,100,-1,1,0, 0,(2 * h),0,0,0)
SetDO(1,1,0,0) -- Turn on vacuum
Lin(Grab,100,-1,0,1,0,0,(h-13), 0,0,0)-- Go to 5 mm below height of box
WaitMs(300) -- Wait to ensure suction
Lin(Grab,50,-1,0,1,0,0,(h+165), 0,0,0) -- Go straight up after grab
-- Either put the go signal for the slave here...
-- SetDO(SlaveGo, 1, 0, 0)
PTP(LeftMidPt,100,500,1, -1 * col * w, 0, z_offset,0,0,0)-- Go to mid pt (might need an ofset in the field)
-- ...or here. Depends on how much faith you have in max speed
-- Place box in prep spot (10mm offset in all directions)
PTP(LeftBIC, 100,500,1, x_offset + 20 ,y_offset + 20, z_offset + 50, 0, 0, 0)
-- Do linear drop to pallet position to ensure minimal colisions or shifting
Lin(LeftBIC,100,500,0,1,x_offset,y_offset,z_offset-10,0,0,0)
SetDO(1,0,0,0) -- Release gripper
WaitMs(300) -- Wait to ensure vacuum is released
Lin(LeftBIC,100,500,0,1,x_offset,y_offset, z_offset+50,0,0,0)
-- Adjust loop values
if(col == max_col) then
    -- PLACE ROTATED BOXES
    SetSysVarValue(s_var_1, layer)
    SetSysVarValue(s_var_2, l)
    SetSysVarValue(s_var_3, w)
    SetSysVarValue(s_var_4, h)
    SetSysVarValue(s_var_5, rail_pos)
    GetSysVarValue(s_var_1)
    
    if(row == max_row) then
        row = 1
        layer = layer + 1
        if(layer == max_layer_low)then
            rail_pos = 50 -- Most likely 100 in the field
            WaitMs(10)
            EXT_AXIS_PTP(0,RailMid,100)
            PTP(LeftPrep,100,0,1,0,0, z_offset, 0,0,0)
        elseif (layer == max_layer_mid) then
            rail_pos = 100 -- Most likely 200 in the field
            EXT_AXIS_PTP(0,RailHigh,100)
            PTP(LeftPrep,100,0,1,0,0, z_offset, 0,0,0)
        end
    else
        row = row + 1
    end
else
    col = col + 1
end
x_offset = -1 * (col * w)
y_offset = -1 * (row * l)
z_offset = (layer * h) - rail_pos 
PTP(LeftPrep,100,0,1,0,0, z_offset, 0,0,0)
    
if (layer == max_layers - 1) then
    box_num = 0
    side = RIGHT
    layer = 0
    col = 0
    row = 0
    rail_pos = 0 -- Reset rail pos
    -- Reset offsets for RIGHT side
    x_offset = -1 * (col * w)
    y_offset = (row * l)
    z_offset = (layer * h) - rail_pos 
    EXT_AXIS_PTP(0,RailLow,100)
    PTP(LeftPrep,100,0,1,0,0, z_offset, 0,0,0)
    SetAuxDO(0,0,0,0) -- Green channel
    SetAuxDO(1,1,0,0) -- YellowChannel
    SetAuxDO(2,0,0,0) -- Red channel
end