--   BIC
--    | [] [] == == | 
--    | == == == == | 
--    | == == == == | 
--    | == == [] [] |
layer = GetSysVarValue(s_var_1)
rail_pos = GetSysVarValue(s_var_2)
l = 445 --Length of 10lb box
w = 248 -- Width of 10lb box
h = 115 -- Height of 10lb box_num

x_offset = 0
y_offset = 0
rot_offset = 0
z_offset = (layer * h) - rail_pos
box_num = 1 
SetAuxDO(0,0,0,0)
SetAuxDO(1,0,0,0)
SetAuxDO(2,1,0,0) -- Use Red
while(1) do
    -- Move to hover pose
    rot_offset = 0
    PTP(Grab,100,-1,1,0, 0,(2 * h) - rail_pos,0,0,0)
    SetDO(1,1,0,0) -- Turn on vacuum
    Lin(Grab,100,-1,0,1,0,0,(h-13) - rail_pos, 0,0,0)-- Go to 5 mm below height of box
    WaitMs(300) -- Wait to ensure suction
    Lin(Grab,50,-1,0,1,0,0,(h+165) - rail_pos, 0,0,0) -- Go straight up after grab
    -- Either put the go signal for the slave here...
    -- SetDO(SlaveGo, 1, 0, 0)
    if(box_num == 1 or box_num == 2) or (box_num == 9 or box_num == 10) then
        if box_num == 1 then
            rot_offset = 90
            x_offset = -1 * ((l - w) / 2)
            y_offset = (l - w) / 2
        elseif box_num == 2 then
            rot_offset = 90
            x_offset = -1 * (l - w) / 2
            y_offset = (l - w) / 2 - w
        elseif box_num == 9 then
            rot_offset = -90
            x_offset = -1 * ((l - w) / 2) - (3 * w)
            y_offset = ((l - w) / 2) - l
        elseif box_num == 10 then
            rot_offset = -90
            x_offset = -1 * ((l - w) / 2) - (3 * w)
            y_offset = ((l - w) / 2) - (l + w)
        end
    end
    if (box_num == 3) then
        y_offset = 0
    
    elseif (box_num == 6) then
        y_offset = -1 * l - ((l - w) / 2)
        x_offset = 0
    end
    PTP(LeftMidPt,100,500,1, 0, 0, z_offset,0,0,rot_offset)-- Go to mid pt (might need an ofset in the field)
    -- ...or here. Depends on how much faith you have in max speed
    -- Place box in prep spot (10mm offset in all directions)
    PTP(LeftBIC, 100,500,1, x_offset - 20 ,y_offset - 20, z_offset + 50, 0, 0, rot_offset)
    Lin(LeftBIC,100,500,0,1,x_offset,y_offset,z_offset-10,0,0,rot_offset)
    SetDO(1,0,0,0) -- Release gripper
    WaitMs(300) -- Wait to ensure vacuum is released
    Lin(LeftBIC,100,500,0,1,x_offset,y_offset, z_offset+100,0,0,rot_offset)
    box_num = box_num + 1
    -- Adjust loop values
    if (box_num == 11) then
        PTP(LeftPrep,100,0,1,0,0, z_offset, 0,0,0)
        break
    else
        x_offset = x_offset - w
    end
end
